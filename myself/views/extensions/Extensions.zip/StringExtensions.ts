﻿interface String {
	/**
	 * String.format(...replacements: string[]): string
	 * @example "This is an {0} for {0} purposes: {1}".format("example", "end");
	 * @ref http://stackoverflow.com/questions/20070158/string-format-not-work-in-typescrypt
	 */
    format(...replacements: string[]): string;
	/**
	 * 左填充，默认为空格填充
	 */
	padLeft(totalWidth: number, paddingChar?: string): string;
	/**
	 * 右填充，默认为空格填充
	 */
	padRight(totalWidth: number, paddingChar?: string): string;
	/**
	 * 确定此字符串实例的开头是否与指定的字符串匹配
	 */
	startsWith(str: string): boolean;
	/**
	 * 确定此字符串实例的结尾是否与指定的字符串匹配
	 */
	endsWith(str: string): boolean;
	/**
	 * 移除末尾空白
	 */
	trimEnd(): string;
	/**
	 * 移除起始空白
	 */
	trimStart(): string;
}

if (!String.prototype.format) {
	String.prototype.format = function (...replacements: string[]): string {
		var args = arguments;
		return this.replace(/{(\d+)}/g, function (match, number) {
			return typeof args[number] !== 'undefined'
				? args[number]
				: match;
		});
	};
}

if (!String.prototype.padLeft) {
	String.prototype.padLeft = function (totalWidth: number, paddingChar?: string): string {
		if (typeof paddingChar !== "string" || paddingChar.length != 1) {
			paddingChar = " ";
		}
		var pad = "";
		while (pad.length + this.length < totalWidth) {
			pad += paddingChar;
		}
		return pad + this;
	}
}

if (!String.prototype.padRight) {
	String.prototype.padRight = function (totalWidth: number, paddingChar?: string): string {
		if (typeof paddingChar !== "string" || paddingChar.length != 1) {
			paddingChar = " ";
		}
		var pad = "";
		while (pad.length + this.length < totalWidth) {
			pad += paddingChar;
		}
		return this + pad;
	}
}

if (!String.prototype.startsWith) {
	String.prototype.startsWith = function (str) {
		if (this == null || str == null)
			return false;
		if (str.length == 0)
			return true;
		if (this.length < str.length)
			return false;
		for (let i = 0; i < str.length; i++) {
			if (this[i] != str[i])
				return false;
		}
		return true;
	}
}

if (!String.prototype.endsWith) {
	String.prototype.endsWith = function (str) {
		if (this == null || str == null)
			return false;
		if (str.length == 0)
			return true;
		if (this.length < str.length)
			return false;
		for (let i = 0; i < str.length; i++) {
			if (this[this.length - 1 - i] != str[str.length - 1 - i])
				return false;
		}
		return true;
	}
}

if (!String.prototype.trimEnd) {
	String.prototype.trimEnd = function () {
		return this.replace(/(\s*$)/g, "");
	}
}

if (!String.prototype.trimStart) {
	String.prototype.trimStart = function () {
		return this.replace(/(^\s*)/g, "");
	}
}



interface String {
	padLeft(totalWidth, paddingChar): string;
}
(<any>String.prototype).padLeft = function (totalWidth, paddingChar): string {
	if (paddingChar != null) {
		return this.PadHelper(totalWidth, paddingChar, false);
	} else {
		return this.PadHelper(totalWidth, ' ', false);
	}
}
interface String {
	PadHelper(totalWidth, paddingChar, isRightPadded): string;
}
(<any>String.prototype).PadHelper = function (totalWidth, paddingChar, isRightPadded): string {
	if (this.length < totalWidth) {
		var paddingString = new String();
		for (var i = 1; i <= (totalWidth - this.length); i++) {
			paddingString += paddingChar;
		}

		if (isRightPadded) {
			return (this + paddingString);
		} else {
			return (paddingString + this);
		}
	} else {
		return this;
	}
}